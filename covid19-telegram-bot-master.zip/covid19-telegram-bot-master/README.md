# COVID STATS

Telegram bot for Coronavirus COVID-19 live updates.
